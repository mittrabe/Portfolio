from tkinter import *
import tkinter as tk
import os
from tkinter import ttk
from PIL import Image, ImageTk

#https://stackoverflow.com/questions/24050068/tkinter-making-classes-for-buttons-and-labels
class ChessSquare(tk.Button):

    def buttonCommand(self):
        print(self.getCoordinates())

   
    def setBackground(self):
            if (self.row+self.column)%2 == 0:
                return '#B58863'
            else:
                return '#F0D9B5'

    def __init__(self, parent, row, col, width, height, **kwargs):
        tk.Button.__init__(self, parent)

        style = ttk.Style()
        style.configure('lightSquare.TFrame', background ="#B58863")
        style.configure('darkSquare.TFrame', background ="#F0D9B5")

        self.row = row
        self.column = col
        self.width = width
        self.height = height
        self.selected = False
        self.highlighted = False
        self['bg'] = self.setBackground()
        self['highlightthickness'] = 0
        self['borderwidth'] = 0

        #self['height'] = int(self.height/56)
        #self['width'] = int(self.height/28)
        self['height'] = int(self.height/4)
        self['width'] = int(self.height/4)

        self['image'] = self.placePiece('empty')
        self.currentPieceType = 'empty'
        self.highlightedBy = 'A0' #A0 is the equivalent to NA or empty


 
        self.grid(row=self.row, column=self.column)
    
    def getRow(self):
        return self.row
    def setRow(self, newRow):
        self.row = newRow

    def getCol(self):
        return self.column
    def setCol(self, newColumn):
        self.column = newColumn

    def getCoordinates(self):
            letters = ['A','B','C','D','E','F','G','H']
            return str(letters[self.column]) + str(self.row+1)

    def getFilePath(self, filename):
            return os.path.realpath(__file__)+f'\\..\\{filename}'

    def placePiece(self, pieceName):

        #pieceName = 'blackPawn'

        pieceWidth = int(self['width']*0.7)
        pieceHeight = int(self['height']*0.7)

        #self.pawn = ImageTk.PhotoImage(Image.open(getFilePath('Chess Pieces\\blackPawn.png')).resize((15, 15), Image.ANTIALIAS))
        self.piece = Image.open(self.getFilePath('Chess Pieces\\' + str(pieceName) + '.png'))
        self.resizedPiece = self.piece.resize((pieceWidth, pieceHeight), Image.ANTIALIAS)
        self.newPiece = ImageTk.PhotoImage(self.resizedPiece)
        self['image'] =  self.newPiece
        self.setCurrentPieceType('pawn')
    
    def removePiece(self):
        pieceWidth = int(self['width']*0.7)
        pieceHeight = int(self['height']*0.7)

        self.piece = Image.open(self.getFilePath('Chess Pieces\\empty.png'))
        self.resizedPiece = self.piece.resize((pieceWidth, pieceHeight), Image.ANTIALIAS)
        self.newPiece = ImageTk.PhotoImage(self.resizedPiece)
        self['image'] =  self.newPiece
        self.setCurrentPieceType('empty')

    def getCurrentPieceType(self):
        return self.currentPieceType
    
    def setCurrentPieceType(self, newPiece):
        self.currentPieceType = newPiece



    def isHighlighted(self):
        return self.highlighted

    def setHighlighted(self, newState):
        self.highlighted = newState

    def getHighlightedBy(self):
        return self.highlightedBy

    def setHighlightedBy(self, coords):
        self.highlightedBy = coords

    #F47C6C <-- piece capture color
    def highlightSquare(self, selectedSquare): 
        lightSquareHighlight = "#FFCB67"
        darkSquareHighlight = "#EEBD5F"

        if (self.row+self.column)%2 == 0:
            self['bg'] = lightSquareHighlight
        else:
            self['bg'] = darkSquareHighlight
        
        self.setHighlighted(True)
        self.setHighlightedBy(selectedSquare.getCoordinates())


    def isSelected(self):
        return self.selected

    def setSelected(self, newState):
        self.selected = newState

    def selectSquare(self):
        style = ttk.Style()
        style.configure('selectedSquare.TFrame', background ="#E59639")
        selectedSquareColor = "#E59639"

        if self['bg'] == selectedSquareColor:
            self['bg'] = self.setBackground()
        else:
            self['bg'] = selectedSquareColor
            self.setSelected(True)
        
        

    def deselectSquare(self):
        self['bg'] = self.setBackground()
        self.setSelected(False)


#class My_Button(Button):
 #   def __init__(self, text, row, col, command, color=None, **kwargs):
  #      self.text = text
   ##    self.column = col
     #   self.command = command
      #  self.color = color
      #  super().__init__()
      #  self['bg'] = self.color
      #  self['text'] = self.text
      #  self['command'] = self.command
      #  self.grid(row=self.row, column=self.column)

